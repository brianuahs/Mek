async function "𝗦𝗖𝗥𝗜𝗣𝗧 𝗥𝗘𝗦𝗠𝗜 𝗭𝗬𝗡𝗫𝗭𝗢 𝗩𝟭𝟰"

let Tq = `
ZynXzo ( Creator )
Tama ( Friend )
Bara ( Friend )
Fitctx ( Friend )
Zuu ( Friend )
Axpaww ( Friend )
Dark Angel ( My Team )`

const message = `
# Thanks Yang Udah Support ZynXzo Dari Dulu Semoga Kalian Sehat Selalu
# Bug Berkerja Menyerang Device Maka Untuk Beta Tidak Di Pastikan C1`